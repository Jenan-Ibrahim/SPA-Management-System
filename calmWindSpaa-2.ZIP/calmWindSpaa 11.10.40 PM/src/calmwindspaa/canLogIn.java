/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calmwindspaa;


public interface canLogIn {  
    
/**
  * These methods will be implemented in the Employee class and Customer class
 * @return boolean = true if username and password are correct
 * @author Esraa Alamoudi, Jenan Mustafa, Ruba Balubaid, Teif Aldadi, Shahad Alharbi
 * @version 2.0
 * 2022/5/23| 1443/10/22
 */
    
    public boolean validUserName();
    public boolean validPassword();
    
 
}
